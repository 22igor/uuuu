# Архитектура платформы заказов металлоизделий

## 📁 Структура проекта (Clean Architecture)

```
src/
├── app/                      # Next.js App Router
│   ├── api/                  # API Routes (Controllers)
│   │   ├── auth/             # Аутентификация
│   │   ├── orders/           # Заказы CRUD
│   │   └── upload/           # Загрузка файлов
│   ├── page.tsx              # Главная страница
│   └── layout.tsx            # Root Layout
│
├── components/               # UI компоненты (shadcn/ui)
│   └── ui/                   # Базовые компоненты
│
├── lib/                      # Библиотеки и утилиты
│   ├── auth/                 # JWT аутентификация
│   ├── queue/                # Клиент очереди
│   ├── storage/              # S3 хранилище (будущее)
│   ├── telegram/             # Telegram Bot (будущее)
│   ├── smm/                  # SMM интеграции (будущее)
│   ├── db.ts                 # Prisma клиент
│   └── utils.ts              # Утилиты
│
├── services/                 # Domain Services (бизнес-логика)
│   ├── orders/               # Сервис заказов
│   ├── users/                # Сервис пользователей
│   ├── production/           # Сервис производства
│   └── smm/                  # SMM сервис
│
├── repositories/             # Data Access Layer (будущее)
│
├── validators/               # Zod схемы валидации
│   └── order.validator.ts
│
├── types/                    # TypeScript типы
│   └── index.ts
│
└── middleware/               # Middleware
    └── auth.ts               # Auth + Rate Limiting

mini-services/
└── production-queue/         # Микросервис очередей
    └── src/
        └── index.ts          # BullMQ Worker

prisma/
└── schema.prisma             # Схема базы данных
```

## 🗄️ Модель данных

### Core Entities

```
┌─────────────┐     ┌─────────────┐     ┌─────────────────┐
│    User     │────<│    Order    │>────│  TrafficSource  │
├─────────────┤     ├─────────────┤     ├─────────────────┤
│ id          │     │ id          │     │ id              │
│ email       │     │ orderNumber │     │ name            │
│ passwordHash│     │ title       │     │ code            │
│ name        │     │ status      │     │ type            │
│ role        │     │ category    │     │ totalLeads      │
│ referralCode│     │ quantity    │     │ totalOrders     │
│ bonusPoints │     │ unit        │     │ totalRevenue    │
└─────────────┘     │ estimatedPr │     └─────────────────┘
      │             │ finalPrice  │
      │             │ utmSource   │
      │             │ utmMedium   │
      │             └─────────────┘
      │                    │
      │             ┌──────┴──────┐
      │             │             │
      │     ┌───────┴───┐  ┌──────┴──────┐
      │     │ OrderFile │  │SMMPost      │
      │     ├───────────┤  ├─────────────┤
      │     │ fileName  │  │ title       │
      │     │ filePath  │  │ content     │
      │     │ fileSize  │  │ platform    │
      │     └───────────┘  │ status      │
      │                    └─────────────┘
      │
      └────────────────── Referral System
```

### Status Flow (Заказ)

```
NEW → CALCULATING → CALCULATED → CONFIRMED → IN_PRODUCTION → PRODUCTION_DONE → READY → DELIVERED → COMPLETED
                                   ↓
                              CANCELLED
```

## 🔄 Queue Architecture

```
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│   Frontend   │─────>│  Next.js API │─────>│   Redis      │
│   (React)    │      │  (REST)      │      │   (BullMQ)   │
└──────────────┘      └──────────────┘      └──────┬───────┘
                                                     │
                              ┌──────────────────────┼──────────────────────┐
                              │                      │                      │
                      ┌───────┴───────┐      ┌───────┴───────┐      ┌───────┴───────┐
                      │   Telegram    │      │     ERP       │      │   CRM         │
                      │   Channel     │      │   Integration │      │   Integration │
                      └───────────────┘      └───────────────┘      └───────────────┘
```

## 🔐 Security

1. **JWT Authentication**
   - Access Token: 15 минут
   - Refresh Token: 7 дней
   - bcrypt хеширование паролей (12 rounds)

2. **Rate Limiting**
   - API: 100 запросов/минута
   - Auth: 10 запросов/минута

3. **Input Validation**
   - Zod схемы для всех входных данных
   - Sanitization от XSS

4. **File Upload**
   - Whitelist MIME-типов
   - Max размер: 50 MB
   - Валидация имени файла

## 📊 SMM Integration

### UTM Tracking
```typescript
// Автоматическое отслеживание
{
  utm_source: 'google',
  utm_medium: 'cpc',
  utm_campaign: 'spring_sale_2024',
  utm_content: 'banner_1',
  utm_term: 'болты_купить'
}
```

### Pixel Events
```typescript
// Facebook Pixel
sendFacebookPixelEvent({
  eventName: 'Lead',        // или 'Purchase'
  userData: { email, phone },
  customData: { value, currency }
});

// VK Pixel
sendVKPixelEvent({ ... });
```

### Auto-posting
```typescript
// Генерация кейса при завершении заказа
const post = generateCasePost(order);
await publishToTelegram(post);
```

## 🚀 Микросервисы (Будущее масштабирование)

### Рекомендуемое разделение:

```
┌─────────────────────────────────────────────────────────────────┐
│                        API Gateway                               │
│                    (Kong / AWS API Gateway)                      │
└──────────────────────────┬──────────────────────────────────────┘
                           │
       ┌───────────────────┼───────────────────┐
       │                   │                   │
       ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│ users-service│   │orders-service│   │smm-service   │
│   :3001      │   │   :3002      │   │   :3003      │
├──────────────┤   ├──────────────┤   ├──────────────┤
│ PostgreSQL   │   │ PostgreSQL   │   │ PostgreSQL   │
│ Redis        │   │ Redis        │   │ Redis        │
└──────────────┘   └──────────────┘   └──────────────┘

       ┌───────────────────┼───────────────────┐
       │                   │                   │
       ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│production-svc│   │notification  │   │analytics-svc │
│   :3004      │   │   :3005      │   │   :3006      │
├──────────────┤   ├──────────────┤   ├──────────────┤
│ PostgreSQL   │   │ Redis        │   │ ClickHouse   │
│ Redis        │   │ Telegram     │   │ PostgreSQL   │
│ BullMQ       │   │ SMTP         │   │              │
└──────────────┘   └──────────────┘   └──────────────┘
```

### Миграция на микросервисы:

1. **users-service** — аутентификация, профили, рефералы
2. **orders-service** — CRUD заказов, расчёты
3. **production-service** — очереди, статусы, интеграции
4. **smm-service** — маркетинг, Pixel, автопостинг
5. **notification-service** — Telegram, Email, SMS
6. **analytics-service** — отчёты, метрики, BI

### Паттерны для микросервисов:

- **Event Sourcing** для заказов
- **Saga** для распределённых транзакций
- **CQRS** для отчётов
- **Circuit Breaker** для внешних API

## 📈 Performance Optimization

1. **Кеширование**
   - Redis для сессий
   - In-memory cache для справочников
   - HTTP Cache для статики

2. **Database**
   - Индексы на частых запросах
   - Connection pooling
   - Read replicas (PostgreSQL)

3. **Queue**
   - BullMQ для фоновых задач
   - Retry с экспоненциальным backoff
   - Dead Letter Queue

## 🧪 Testing Strategy

```
Unit Tests → Integration Tests → E2E Tests
    │              │                 │
    ▼              ▼                 ▼
 Vitest      Supertest         Playwright
 (Services)  (API Routes)      (User Flows)
```

## 📝 Environment Variables

```env
# Database
DATABASE_URL="file:./db/custom.db"

# Auth
JWT_SECRET="your-super-secret-key-change-in-production"

# Telegram
TELEGRAM_BOT_TOKEN="your-bot-token"
TELEGRAM_CHANNEL_ID="@your_channel"
TELEGRAM_PRODUCTION_CHAT_ID="-1001234567890"

# SMM
FACEBOOK_PIXEL_ID="123456789"
FACEBOOK_PIXEL_ACCESS_TOKEN="your-token"
VK_PIXEL_ID="VK-RTRG-123456"

# Redis (Production)
REDIS_HOST="localhost"
REDIS_PORT="6379"

# Queue Service
QUEUE_SERVICE_URL="http://localhost:3002"
```

## 🛠️ Запуск проекта

```bash
# Development
bun run dev              # Next.js на :3000
cd mini-services/production-queue && bun run dev  # Queue на :3002

# Database
bun run db:push          # Применить схему
bun run db:studio        # Prisma Studio

# Linting
bun run lint             # ESLint проверка
```

---

© 2024 МетизЭксперт — Production-Ready Platform
