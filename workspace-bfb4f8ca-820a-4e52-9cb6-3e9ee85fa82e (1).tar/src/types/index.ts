// ============================================================================
// TYPES - Общие типы для всей платформы
// ============================================================================

// re-export Prisma types
export type { User, Order, OrderFile, OrderStatusHistory, TrafficSource, SMMPost, QueueJobLog, Notification, Setting, Integration } from '@prisma/client';

// ============================================================================
// API Response Types
// ============================================================================

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ============================================================================
// Order Types
// ============================================================================

export interface CreateOrderInput {
  // Контактные данные
  contactName: string;
  contactPhone: string;
  contactEmail?: string;
  
  // Детали заказа
  title: string;
  description?: string;
  category: 'FASTENERS' | 'STRUCTURES' | 'SHEET_METAL' | 'PIPES' | 'CUSTOM';
  quantity: number;
  unit: string;
  
  // Материал
  materialType?: string;
  materialGrade?: string;
  
  // Доставка
  deliveryAddress?: string;
  deliveryType: 'PICKUP' | 'DELIVERY' | 'TRANSPORT';
  
  // Сроки
  deadline?: string;
  
  // UTM-метки
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
  
  // Реферал
  referralCode?: string;
}

export interface OrderWithFiles {
  id: string;
  orderNumber: string;
  status: string;
  title: string;
  estimatedPrice: number | null;
  finalPrice: number | null;
  createdAt: Date;
  files: Array<{
    id: string;
    fileName: string;
    filePath: string;
  }>;
}

export interface OrderCalculation {
  orderId: string;
  estimatedPrice: number; // В копейках
  estimatedDays: number;
  notes?: string;
}

// ============================================================================
// Production Queue Types
// ============================================================================

export interface ProductionJobData {
  orderId: string;
  orderNumber: string;
  action: 'SEND_TO_PRODUCTION' | 'UPDATE_STATUS' | 'SEND_NOTIFICATION';
  payload?: Record<string, unknown>;
}

export interface TelegramMessage {
  chatId: string;
  text: string;
  parseMode?: 'HTML' | 'Markdown';
  replyMarkup?: unknown;
}

// ============================================================================
// SMM Types
// ============================================================================

export interface UTMParams {
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
}

export interface PixelEvent {
  eventName: 'Lead' | 'Purchase' | 'AddToCart' | 'CompleteRegistration';
  eventId?: string;
  userData?: {
    email?: string;
    phone?: string;
    externalId?: string;
  };
  customData?: {
    value?: number;
    currency?: string;
    contentName?: string;
    contentType?: string;
  };
}

export interface SMMPostTemplate {
  title: string;
  content: string;
  imageUrl?: string;
  tags: string[];
}

// ============================================================================
// Auth Types
// ============================================================================

export interface JwtPayload {
  userId: string;
  email: string;
  role: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

// ============================================================================
// File Upload Types
// ============================================================================

export interface UploadedFile {
  id: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
}

export interface FileUploadResult {
  success: boolean;
  file?: UploadedFile;
  error?: string;
}
