// ============================================================================
// AUTH - JWT Authentication Library
// ============================================================================

import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import type { User, JwtPayload, AuthTokens } from '@/types';

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key-change-in-production';
const JWT_EXPIRES_IN = '15m';
const REFRESH_TOKEN_EXPIRES_IN = '7d';

// ============================================================================
// Password Functions
// ============================================================================

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ============================================================================
// JWT Functions
// ============================================================================

export function generateTokens(user: Pick<User, 'id' | 'email' | 'role'>): AuthTokens {
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
  };
  
  const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  const refreshToken = jwt.sign(
    { ...payload, type: 'refresh' },
    JWT_SECRET,
    { expiresIn: REFRESH_TOKEN_EXPIRES_IN }
  );
  
  return { accessToken, refreshToken };
}

export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

// ============================================================================
// Auth Helpers
// ============================================================================

export async function getUserFromToken(token: string): Promise<User | null> {
  const payload = verifyToken(token);
  if (!payload) return null;
  
  const user = await db.user.findUnique({
    where: { id: payload.userId },
  });
  
  return user?.isActive ? user : null;
}

export async function authenticateUser(email: string, password: string): Promise<{ user: User; tokens: AuthTokens } | null> {
  const user = await db.user.findUnique({
    where: { email: email.toLowerCase() },
  });
  
  if (!user || !user.isActive) return null;
  
  const isValid = await verifyPassword(password, user.passwordHash);
  if (!isValid) return null;
  
  // Update last login
  await db.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });
  
  const tokens = generateTokens(user);
  
  return { user, tokens };
}

export async function registerUser(data: {
  email: string;
  password: string;
  name?: string;
  phone?: string;
  referralCode?: string;
}): Promise<{ user: User; tokens: AuthTokens }> {
  const hashedPassword = await hashPassword(data.password);
  
  // Генерация реферального кода
  const referralCode = generateReferralCode();
  
  // Проверка реферала
  let referredBy: string | undefined;
  if (data.referralCode) {
    const referrer = await db.user.findUnique({
      where: { referralCode: data.referralCode },
    });
    if (referrer) {
      referredBy = referrer.id;
    }
  }
  
  const user = await db.user.create({
    data: {
      email: data.email.toLowerCase(),
      passwordHash: hashedPassword,
      name: data.name,
      phone: data.phone,
      referralCode,
      referredBy,
      role: 'CLIENT',
      // Бонус за регистрацию по рефералу
      bonusPoints: referredBy ? 100 : 0,
    },
  });
  
  // Начисляем бонус рефереру
  if (referredBy) {
    await db.user.update({
      where: { id: referredBy },
      data: { bonusPoints: { increment: 100 } },
    });
  }
  
  const tokens = generateTokens(user);
  
  return { user, tokens };
}

function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'ME';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// ============================================================================
// Session Management
// ============================================================================

export function extractTokenFromHeader(authHeader: string | null): string | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  return authHeader.slice(7);
}
