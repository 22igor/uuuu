// ============================================================================
// QUEUE CLIENT - Клиент для работы с Production Queue
// ============================================================================
// Используется в основном приложении для отправки задач в очередь
// ============================================================================

import type { Order } from '@prisma/client';

const QUEUE_SERVICE_URL = process.env.QUEUE_SERVICE_URL || 'http://localhost:3002';

// ============================================================================
// Types
// ============================================================================

interface ProductionJobData {
  orderId: string;
  orderNumber: string;
  action: 'SEND_TO_PRODUCTION' | 'UPDATE_STATUS' | 'SEND_NOTIFICATION';
  payload?: Record<string, unknown>;
}

// ============================================================================
// Queue Client
// ============================================================================

/**
 * Добавить задачу в очередь производства
 */
export async function enqueueProductionJob(
  data: ProductionJobData
): Promise<{ success: boolean; jobId?: string; error?: string }> {
  try {
    const response = await fetch(`${QUEUE_SERVICE_URL}/api/jobs?XTransformPort=3002`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    
    const result = await response.json() as { success: boolean; jobId?: string; error?: string };
    return result;
  } catch (error) {
    console.error('Failed to enqueue job:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Отправить заказ в производство
 */
export async function sendOrderToProduction(order: Order): Promise<void> {
  await enqueueProductionJob({
    orderId: order.id,
    orderNumber: order.orderNumber,
    action: 'SEND_TO_PRODUCTION',
    payload: {
      title: order.title,
      description: order.description,
      quantity: order.quantity,
      unit: order.unit,
      material: order.materialType
        ? `${order.materialType}${order.materialGrade ? ` ${order.materialGrade}` : ''}`
        : undefined,
      deadline: order.deadline?.toISOString(),
    },
  });
}

/**
 * Отправить уведомление об изменении статуса
 */
export async function notifyStatusChange(
  order: Order,
  newStatus: string,
  comment?: string
): Promise<void> {
  await enqueueProductionJob({
    orderId: order.id,
    orderNumber: order.orderNumber,
    action: 'UPDATE_STATUS',
    payload: {
      status: getStatusLabel(newStatus),
      comment,
    },
  });
}

/**
 * Отправить кастомное уведомление
 */
export async function sendNotification(
  chatId: string,
  message: string
): Promise<void> {
  await enqueueProductionJob({
    orderId: 'notification',
    orderNumber: 'notification',
    action: 'SEND_NOTIFICATION',
    payload: {
      chatId,
      message,
    },
  });
}

/**
 * Получить статус очереди
 */
export async function getQueueStatus(): Promise<{
  waiting: number;
  active: number;
  completed: number;
  failed: number;
}> {
  try {
    const response = await fetch(`${QUEUE_SERVICE_URL}/api/queue/status?XTransformPort=3002`);
    return response.json() as Promise<{
      waiting: number;
      active: number;
      completed: number;
      failed: number;
    }>;
  } catch {
    return { waiting: 0, active: 0, completed: 0, failed: 0 };
  }
}

// ============================================================================
// Helpers
// ============================================================================

function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    NEW: '🆕 Новая заявка',
    CALCULATING: '🔢 На расчёте',
    CALCULATED: '✅ Рассчитано',
    CONFIRMED: '📌 Подтверждён',
    IN_PRODUCTION: '🏭 В производстве',
    PRODUCTION_DONE: '✅ Произведено',
    READY: '📦 Готово к выдаче',
    DELIVERED: '🚚 Доставлено',
    COMPLETED: '🎉 Завершён',
    CANCELLED: '❌ Отменён',
  };
  
  return labels[status] || status;
}
