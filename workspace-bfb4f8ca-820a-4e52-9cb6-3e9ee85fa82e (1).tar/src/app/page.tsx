// ============================================================================
// ГЛАВНАЯ СТРАНИЦА - Форма заказа металлоизделий
// ============================================================================

'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Card, CardContent, CardDescription, CardHeader, CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Alert,
  AlertDescription,
} from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Hammer,
  Upload,
  CheckCircle2,
  Loader2,
  Phone,
  Mail,
  MapPin,
  Clock,
  Shield,
  Award,
  Users,
  FileText,
  Settings,
  BarChart3,
  LogIn,
  UserPlus,
  X,
  Calculator,
  Truck,
  Package,
} from 'lucide-react';
import { toast } from 'sonner';

// ============================================================================
// Validation Schema
// ============================================================================

const orderFormSchema = z.object({
  contactName: z.string().min(2, 'Минимум 2 символа'),
  contactPhone: z.string().regex(/^\+?[0-9\s\-()]{10,20}$/, 'Некорректный телефон'),
  contactEmail: z.string().email('Некорректный email').optional().or(z.literal('')),
  title: z.string().min(5, 'Минимум 5 символов'),
  description: z.string().max(5000).optional(),
  category: z.enum(['FASTENERS', 'STRUCTURES', 'SHEET_METAL', 'PIPES', 'CUSTOM']),
  quantity: z.number().int().positive('Количество должно быть > 0'),
  unit: z.string().min(1, 'Укажите единицу'),
  materialType: z.string().optional(),
  materialGrade: z.string().optional(),
  deliveryType: z.enum(['PICKUP', 'DELIVERY', 'TRANSPORT']),
  deliveryAddress: z.string().optional(),
  deadline: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderFormSchema>;

// ============================================================================
// Category Config
// ============================================================================

const CATEGORIES = [
  { value: 'FASTENERS', label: 'Крепёжные изделия', icon: '🔩', desc: 'Болты, гайки, винты, шпильки' },
  { value: 'STRUCTURES', label: 'Металлоконструкции', icon: '🏗️', desc: 'Балки, фермы, каркасы' },
  { value: 'SHEET_METAL', label: 'Листовой металл', icon: '📋', desc: 'Листы, полосы, ленты' },
  { value: 'PIPES', label: 'Трубы', icon: '🔧', desc: 'Трубы различных диаметров' },
  { value: 'CUSTOM', label: 'Нестандартное', icon: '⚙️', desc: 'Индивидуальные заказы' },
];

const UNITS = ['шт', 'м', 'кг', 'м²', 'м³', 'комплект'];

// ============================================================================
// Component
// ============================================================================

export default function OrderPage() {
  const [activeTab, setActiveTab] = useState('order');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [createdOrderNumber, setCreatedOrderNumber] = useState<string>('');
  
  // UTM параметры
  const [utmParams, setUtmParams] = useState<Record<string, string>>({});
  
  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<{ id: string; name: string; email: string } | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Форма заказа
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
    reset,
  } = useForm<OrderFormData>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      deliveryType: 'PICKUP',
      unit: 'шт',
      quantity: 1,
    },
  });

  // Форма авторизации
  const [authForm, setAuthForm] = useState({
    email: '',
    password: '',
    name: '',
    phone: '',
  });

  // Загрузка UTM параметров
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const utm: Record<string, string> = {};
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(key => {
      const value = params.get(key);
      if (value) utm[key] = value;
    });
    setUtmParams(utm);
  }, []);

  // Проверка авторизации
  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
        setIsLoggedIn(true);
      } catch {
        // ignore
      }
    }
  }, []);

  // Обработка авторизации
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: authMode,
          ...authForm,
          ...utmParams,
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        localStorage.setItem('accessToken', data.data.accessToken);
        localStorage.setItem('refreshToken', data.data.refreshToken);
        localStorage.setItem('user', JSON.stringify(data.data.user));
        setUser(data.data.user);
        setIsLoggedIn(true);
        setShowAuth(false);
        toast.success(authMode === 'login' ? 'Вход выполнен успешно!' : 'Регистрация успешна!');
      } else {
        toast.error(data.error || 'Ошибка авторизации');
      }
    } catch {
      toast.error('Ошибка соединения');
    }
  };

  // Отправка формы заказа
  const onSubmit = async (data: OrderFormData) => {
    if (!isLoggedIn) {
      setShowAuth(true);
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Загрузка файлов если есть
      const uploadedFileUrls: string[] = [];
      
      for (const file of uploadedFiles) {
        const formData = new FormData();
        formData.append('file', file);
        
        const uploadRes = await fetch('/api/upload', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          },
          body: formData,
        });
        
        const uploadData = await uploadRes.json();
        if (uploadData.success) {
          uploadedFileUrls.push(uploadData.data.filePath);
        }
      }

      // Создание заказа
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
        },
        body: JSON.stringify({
          ...data,
          ...utmParams,
          deadline: data.deadline || undefined,
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        setCreatedOrderNumber(result.data.orderNumber);
        setIsSuccess(true);
        reset();
        setUploadedFiles([]);
        toast.success('Заказ успешно создан!');
      } else {
        toast.error(result.error || 'Ошибка создания заказа');
      }
    } catch {
      toast.error('Ошибка соединения');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Выход
  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    setUser(null);
    setIsLoggedIn(false);
    toast.info('Вы вышли из системы');
  };

  const category = watch('category');
  const deliveryType = watch('deliveryType');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500 rounded-lg">
                <Hammer className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">МетизЭксперт</h1>
                <p className="text-xs text-slate-400">Производство металлоизделий</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {isLoggedIn ? (
                <div className="flex items-center gap-3">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-medium text-white">{user?.name || user?.email}</p>
                    <Badge variant="secondary" className="text-xs">Клиент</Badge>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    Выйти
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setShowAuth(true)}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Войти
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Users, value: '1500+', label: 'Клиентов' },
            { icon: Package, value: '5000+', label: 'Заказов' },
            { icon: Clock, value: '14 лет', label: 'На рынке' },
            { icon: Award, value: '98%', label: 'Довольных' },
          ].map((stat, i) => (
            <Card key={i} className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4 text-center">
                <stat.icon className="w-8 h-8 mx-auto mb-2 text-orange-500" />
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-sm text-slate-400">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
            <TabsTrigger value="order" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">Новый заказ</span>
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Мои заказы</span>
            </TabsTrigger>
            <TabsTrigger value="calculator" className="flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              <span className="hidden sm:inline">Калькулятор</span>
            </TabsTrigger>
          </TabsList>

          {/* Order Form Tab */}
          <TabsContent value="order">
            {isSuccess ? (
              <Card className="bg-slate-800/50 border-green-500/50">
                <CardContent className="p-8 text-center">
                  <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h2 className="text-2xl font-bold text-white mb-2">Заказ успешно создан!</h2>
                  <p className="text-slate-400 mb-4">
                    Номер вашего заказа: <Badge variant="secondary" className="ml-2">{createdOrderNumber}</Badge>
                  </p>
                  <p className="text-slate-400 mb-6">
                    Наш менеджер свяжется с вами в ближайшее время для уточнения деталей.
                  </p>
                  <Button onClick={() => setIsSuccess(false)}>
                    Создать новый заказ
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="grid lg:grid-cols-3 gap-6">
                  {/* Main Form */}
                  <div className="lg:col-span-2 space-y-6">
                    {/* Contact Info */}
                    <Card className="bg-slate-800/50 border-slate-700">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <Phone className="w-5 h-5 text-orange-500" />
                          Контактные данные
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-slate-300">Контактное лицо *</Label>
                          <Input
                            {...register('contactName')}
                            placeholder="Иван Иванов"
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                          {errors.contactName && (
                            <p className="text-red-400 text-sm">{errors.contactName.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-slate-300">Телефон *</Label>
                          <Input
                            {...register('contactPhone')}
                            placeholder="+7 (999) 123-45-67"
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                          {errors.contactPhone && (
                            <p className="text-red-400 text-sm">{errors.contactPhone.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2 md:col-span-2">
                          <Label className="text-slate-300">Email</Label>
                          <Input
                            type="email"
                            {...register('contactEmail')}
                            placeholder="email@example.com"
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                          {errors.contactEmail && (
                            <p className="text-red-400 text-sm">{errors.contactEmail.message}</p>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Order Details */}
                    <Card className="bg-slate-800/50 border-slate-700">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <Hammer className="w-5 h-5 text-orange-500" />
                          Детали заказа
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {/* Category Selection */}
                        <div className="space-y-2">
                          <Label className="text-slate-300">Категория продукции *</Label>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                            {CATEGORIES.map((cat) => (
                              <button
                                key={cat.value}
                                type="button"
                                onClick={() => setValue('category', cat.value as any)}
                                className={`p-3 rounded-lg border text-left transition-all ${
                                  category === cat.value
                                    ? 'border-orange-500 bg-orange-500/10'
                                    : 'border-slate-600 bg-slate-700/50 hover:border-slate-500'
                                }`}
                              >
                                <span className="text-xl">{cat.icon}</span>
                                <p className="text-sm font-medium text-white mt-1">{cat.label}</p>
                                <p className="text-xs text-slate-400">{cat.desc}</p>
                              </button>
                            ))}
                          </div>
                          {errors.category && (
                            <p className="text-red-400 text-sm">{errors.category.message}</p>
                          )}
                        </div>

                        {/* Title */}
                        <div className="space-y-2">
                          <Label className="text-slate-300">Наименование *</Label>
                          <Input
                            {...register('title')}
                            placeholder="Болт М12×50 ГОСТ 7798-70"
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                          {errors.title && (
                            <p className="text-red-400 text-sm">{errors.title.message}</p>
                          )}
                        </div>

                        {/* Description */}
                        <div className="space-y-2">
                          <Label className="text-slate-300">Описание</Label>
                          <Textarea
                            {...register('description')}
                            placeholder="Подробное описание заказа..."
                            rows={4}
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                        </div>

                        {/* Quantity & Unit */}
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">Количество *</Label>
                            <Input
                              type="number"
                              {...register('quantity', { valueAsNumber: true })}
                              className="bg-slate-700 border-slate-600 text-white"
                            />
                            {errors.quantity && (
                              <p className="text-red-400 text-sm">{errors.quantity.message}</p>
                            )}
                          </div>
                          
                          <div className="space-y-2">
                            <Label className="text-slate-300">Единица измерения *</Label>
                            <Select 
                              defaultValue="шт" 
                              onValueChange={(value) => setValue('unit', value)}
                            >
                              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {UNITS.map((unit) => (
                                  <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Material */}
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">Материал</Label>
                            <Input
                              {...register('materialType')}
                              placeholder="Сталь"
                              className="bg-slate-700 border-slate-600 text-white"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label className="text-slate-300">Марка материала</Label>
                            <Input
                              {...register('materialGrade')}
                              placeholder="Ст3сп"
                              className="bg-slate-700 border-slate-600 text-white"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Delivery */}
                    <Card className="bg-slate-800/50 border-slate-700">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <Truck className="w-5 h-5 text-orange-500" />
                          Доставка
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { value: 'PICKUP', label: 'Самовывоз', icon: '🏢' },
                            { value: 'DELIVERY', label: 'Доставка', icon: '🚚' },
                            { value: 'TRANSPORT', label: 'ТК', icon: '📦' },
                          ].map((d) => (
                            <button
                              key={d.value}
                              type="button"
                              onClick={() => setValue('deliveryType', d.value as any)}
                              className={`p-3 rounded-lg border text-center transition-all ${
                                deliveryType === d.value
                                  ? 'border-orange-500 bg-orange-500/10'
                                  : 'border-slate-600 bg-slate-700/50 hover:border-slate-500'
                              }`}
                            >
                              <span className="text-xl">{d.icon}</span>
                              <p className="text-sm text-white mt-1">{d.label}</p>
                            </button>
                          ))}
                        </div>

                        {deliveryType !== 'PICKUP' && (
                          <div className="space-y-2">
                            <Label className="text-slate-300">Адрес доставки</Label>
                            <Textarea
                              {...register('deliveryAddress')}
                              placeholder="Город, улица, дом..."
                              rows={2}
                              className="bg-slate-700 border-slate-600 text-white"
                            />
                          </div>
                        )}

                        <div className="space-y-2">
                          <Label className="text-slate-300">Желаемый срок</Label>
                          <Input
                            type="date"
                            {...register('deadline')}
                            min={new Date().toISOString().split('T')[0]}
                            className="bg-slate-700 border-slate-600 text-white"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* File Upload */}
                    <Card className="bg-slate-800/50 border-slate-700">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <Upload className="w-5 h-5 text-orange-500" />
                          Чертежи и файлы
                        </CardTitle>
                        <CardDescription className="text-slate-400">
                          Загрузите чертежи, спецификации или другие документы
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center">
                          <Upload className="w-10 h-10 mx-auto mb-4 text-slate-400" />
                          <p className="text-slate-400 mb-2">
                            Перетащите файлы сюда или кликните для выбора
                          </p>
                          <p className="text-xs text-slate-500 mb-4">
                            PDF, DOC, DOCX, XLS, XLSX, DWG, JPG, PNG (макс. 50 МБ)
                          </p>
                          <input
                            type="file"
                            multiple
                            accept=".pdf,.doc,.docx,.xls,.xlsx,.dwg,.jpg,.jpeg,.png"
                            onChange={(e) => {
                              const files = Array.from(e.target.files || []);
                              setUploadedFiles((prev) => [...prev, ...files]);
                            }}
                            className="hidden"
                            id="file-upload"
                          />
                          <Button type="button" variant="outline" asChild>
                            <label htmlFor="file-upload" className="cursor-pointer">
                              Выбрать файлы
                            </label>
                          </Button>
                        </div>

                        {uploadedFiles.length > 0 && (
                          <div className="mt-4 space-y-2">
                            {uploadedFiles.map((file, i) => (
                              <div
                                key={i}
                                className="flex items-center justify-between p-2 bg-slate-700 rounded-lg"
                              >
                                <span className="text-sm text-white truncate">
                                  📎 {file.name}
                                </span>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setUploadedFiles((prev) =>
                                      prev.filter((_, index) => index !== i)
                                    );
                                  }}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Sidebar */}
                  <div className="space-y-6">
                    {/* Summary Card */}
                    <Card className="bg-slate-800/50 border-slate-700 sticky top-24">
                      <CardHeader>
                        <CardTitle className="text-white">Итого</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between text-slate-400">
                            <span>Категория:</span>
                            <span className="text-white">
                              {CATEGORIES.find((c) => c.value === category)?.label || '-'}
                            </span>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Количество:</span>
                            <span className="text-white">{watch('quantity') || 0} {watch('unit')}</span>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Доставка:</span>
                            <span className="text-white">
                              {deliveryType === 'PICKUP' ? 'Самовывоз' : 
                               deliveryType === 'DELIVERY' ? 'Доставка' : 'Транспортная компания'}
                            </span>
                          </div>
                        </div>

                        <Separator className="bg-slate-700" />

                        <Alert className="bg-orange-500/10 border-orange-500/30">
                          <AlertDescription className="text-orange-200 text-sm">
                            Точная стоимость будет рассчитана менеджером после обработки заявки
                          </AlertDescription>
                        </Alert>

                        <Button
                          type="submit"
                          className="w-full bg-orange-500 hover:bg-orange-600"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Отправка...
                            </>
                          ) : (
                            'Отправить заявку'
                          )}
                        </Button>

                        <p className="text-xs text-slate-500 text-center">
                          Нажимая кнопку, вы соглашаетесь с{' '}
                          <a href="#" className="text-orange-400 hover:underline">
                            политикой конфиденциальности
                          </a>
                        </p>
                      </CardContent>
                    </Card>

                    {/* Trust Badges */}
                    <Card className="bg-slate-800/50 border-slate-700">
                      <CardContent className="p-4 space-y-3">
                        {[
                          { icon: Shield, text: 'Гарантия качества' },
                          { icon: Clock, text: 'Соблюдение сроков' },
                          { icon: Award, text: 'Сертифицированная продукция' },
                          { icon: Settings, text: 'Индивидуальный подход' },
                        ].map((item, i) => (
                          <div key={i} className="flex items-center gap-3">
                            <item.icon className="w-5 h-5 text-orange-500" />
                            <span className="text-sm text-slate-300">{item.text}</span>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </form>
            )}
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Мои заказы</CardTitle>
                <CardDescription className="text-slate-400">
                  История и статус ваших заказов
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!isLoggedIn ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 mx-auto mb-4 text-slate-500" />
                    <p className="text-slate-400 mb-4">
                      Войдите в систему, чтобы увидеть ваши заказы
                    </p>
                    <Button onClick={() => setShowAuth(true)}>
                      <LogIn className="w-4 h-4 mr-2" />
                      Войти
                    </Button>
                  </div>
                ) : (
                  <OrdersList token={localStorage.getItem('accessToken') || ''} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Calculator Tab */}
          <TabsContent value="calculator">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-orange-500" />
                  Калькулятор стоимости
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Ориентировочный расчёт стоимости заказа
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-slate-300">Тип изделия</Label>
                      <Select defaultValue="bolt">
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bolt">Болт</SelectItem>
                          <SelectItem value="nut">Гайка</SelectItem>
                          <SelectItem value="washer">Шайба</SelectItem>
                          <SelectItem value="stud">Шпилька</SelectItem>
                          <SelectItem value="custom">Нестандартное</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-300">Материал</Label>
                      <Select defaultValue="steel">
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="steel">Сталь Ст3</SelectItem>
                          <SelectItem value="steel45">Сталь 45</SelectItem>
                          <SelectItem value="steel40x">Сталь 40Х</SelectItem>
                          <SelectItem value="stainless">Нержавеющая сталь</SelectItem>
                          <SelectItem value="brass">Латунь</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-300">Диаметр (мм)</Label>
                      <Input
                        type="number"
                        defaultValue="12"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-300">Длина (мм)</Label>
                      <Input
                        type="number"
                        defaultValue="50"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-300">Количество (шт)</Label>
                      <Input
                        type="number"
                        defaultValue="100"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-slate-700/50 rounded-lg p-6">
                      <h3 className="text-lg font-semibold text-white mb-4">Ориентировочная стоимость</h3>
                      <p className="text-4xl font-bold text-orange-500 mb-2">~ 2 500 ₽</p>
                      <p className="text-sm text-slate-400">
                        Точная стоимость рассчитывается после обработки заявки
                      </p>
                    </div>

                    <Alert className="bg-blue-500/10 border-blue-500/30">
                      <AlertDescription className="text-blue-200 text-sm">
                        Калькулятор показывает ориентировочную стоимость. 
                        Итоговая цена зависит от сложности изделия, покрытия и объёма.
                      </AlertDescription>
                    </Alert>

                    <Button
                      className="w-full"
                      onClick={() => setActiveTab('order')}
                    >
                      Оформить заказ
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Auth Modal */}
      {showAuth && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="bg-slate-800 border-slate-700 w-full max-w-md">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">
                  {authMode === 'login' ? 'Вход в систему' : 'Регистрация'}
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAuth(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAuth} className="space-y-4">
                {authMode === 'register' && (
                  <div className="space-y-2">
                    <Label className="text-slate-300">Имя</Label>
                    <Input
                      value={authForm.name}
                      onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Email</Label>
                  <Input
                    type="email"
                    value={authForm.email}
                    onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Пароль</Label>
                  <Input
                    type="password"
                    value={authForm.password}
                    onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  {authMode === 'login' ? (
                    <>
                      <LogIn className="w-4 h-4 mr-2" />
                      Войти
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Зарегистрироваться
                    </>
                  )}
                </Button>

                <div className="text-center text-sm text-slate-400">
                  {authMode === 'login' ? (
                    <>
                      Нет аккаунта?{' '}
                      <button
                        type="button"
                        onClick={() => setAuthMode('register')}
                        className="text-orange-400 hover:underline"
                      >
                        Зарегистрироваться
                      </button>
                    </>
                  ) : (
                    <>
                      Уже есть аккаунт?{' '}
                      <button
                        type="button"
                        onClick={() => setAuthMode('login')}
                        className="text-orange-400 hover:underline"
                      >
                        Войти
                      </button>
                    </>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Hammer className="w-5 h-5 text-orange-500" />
              <span className="text-white font-semibold">МетизЭксперт</span>
            </div>
            <p className="text-sm text-slate-400 text-center">
              © 2024 МетизЭксперт. Все права защищены.
            </p>
            <div className="flex items-center gap-4 text-sm text-slate-400">
              <a href="tel:+79991234567" className="flex items-center gap-1 hover:text-white">
                <Phone className="w-4 h-4" />
                +7 (999) 123-45-67
              </a>
              <a href="mailto:info@metizexpert.ru" className="flex items-center gap-1 hover:text-white">
                <Mail className="w-4 h-4" />
                info@metizexpert.ru
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ============================================================================
// Orders List Component
// ============================================================================

function OrdersList({ token }: { token: string }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      fetchOrders();
    }
  }, [token]);

  const fetchOrders = async () => {
    try {
      const response = await fetch('/api/orders', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (data.success) {
        setOrders(data.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const config: Record<string, { label: string; className: string }> = {
      NEW: { label: 'Новая', className: 'bg-blue-500/20 text-blue-400' },
      CALCULATING: { label: 'На расчёте', className: 'bg-yellow-500/20 text-yellow-400' },
      CALCULATED: { label: 'Рассчитано', className: 'bg-purple-500/20 text-purple-400' },
      CONFIRMED: { label: 'Подтверждён', className: 'bg-green-500/20 text-green-400' },
      IN_PRODUCTION: { label: 'В производстве', className: 'bg-orange-500/20 text-orange-400' },
      READY: { label: 'Готово', className: 'bg-emerald-500/20 text-emerald-400' },
      COMPLETED: { label: 'Завершён', className: 'bg-slate-500/20 text-slate-400' },
      CANCELLED: { label: 'Отменён', className: 'bg-red-500/20 text-red-400' },
    };
    
    const { label, className } = config[status] || { label: status, className: 'bg-slate-500/20 text-slate-400' };
    return <Badge className={className}>{label}</Badge>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 mx-auto mb-4 text-slate-500" />
        <p className="text-slate-400 mb-4">У вас пока нет заказов</p>
        <p className="text-sm text-slate-500">Создайте свой первый заказ!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div
          key={order.id}
          className="p-4 bg-slate-700/50 rounded-lg border border-slate-600"
        >
          <div className="flex items-start justify-between mb-2">
            <div>
              <p className="font-semibold text-white">{order.orderNumber}</p>
              <p className="text-sm text-slate-400">{order.title}</p>
            </div>
            {getStatusBadge(order.status)}
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-400">
            <span>{order.quantity} {order.unit}</span>
            <span>•</span>
            <span>{new Date(order.createdAt).toLocaleDateString('ru-RU')}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
