// ============================================================================
// API: /api/auth - Аутентификация и регистрация
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { registerUser, authenticateUser } from '@/lib/auth';
import { rateLimit } from '@/middleware/auth';
import { registerSchema, loginSchema } from '@/validators/order.validator';
import { trackUTM } from '@/services/smm';

// Stricter rate limit for auth endpoints
const authLimiter = rateLimit({ windowMs: 60 * 1000, maxRequests: 10 });

// ============================================================================
// POST /api/auth/register - Регистрация нового пользователя
// ============================================================================

export async function POST(request: NextRequest) {
  const rateLimitResponse = await authLimiter(request);
  if (rateLimitResponse) return rateLimitResponse;
  
  try {
    const body = await request.json();
    
    // Определяем тип запроса
    const { action } = body;
    
    if (action === 'login') {
      return handleLogin(body);
    }
    
    return handleRegister(body);
    
  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json({
      success: false,
      error: 'Ошибка сервера',
    }, { status: 500 });
  }
}

async function handleRegister(body: Record<string, unknown>) {
  try {
    const validatedData = registerSchema.parse(body);
    
    // Трекаем UTM если есть
    if (body.utmSource) {
      await trackUTM({
        utmSource: body.utmSource as string,
        utmMedium: body.utmMedium as string,
        utmCampaign: body.utmCampaign as string,
      });
    }
    
    const { user, tokens } = await registerUser(validatedData);
    
    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          referralCode: user.referralCode,
          bonusPoints: user.bonusPoints,
        },
        ...tokens,
      },
      message: 'Регистрация успешна',
    }, { status: 201 });
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Ошибка валидации',
        details: error.errors,
      }, { status: 400 });
    }
    
    // Проверяем на дубликат email
    if (String(error).includes('Unique constraint')) {
      return NextResponse.json({
        success: false,
        error: 'Пользователь с таким email уже существует',
      }, { status: 409 });
    }
    
    throw error;
  }
}

async function handleLogin(body: Record<string, unknown>) {
  try {
    const validatedData = loginSchema.parse(body);
    
    const result = await authenticateUser(validatedData.email, validatedData.password);
    
    if (!result) {
      return NextResponse.json({
        success: false,
        error: 'Неверный email или пароль',
      }, { status: 401 });
    }
    
    const { user, tokens } = result;
    
    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          referralCode: user.referralCode,
          bonusPoints: user.bonusPoints,
        },
        ...tokens,
      },
      message: 'Вход выполнен успешно',
    });
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Ошибка валидации',
        details: error.errors,
      }, { status: 400 });
    }
    
    throw error;
  }
}
