// ============================================================================
// API: /api/orders - CRUD для заказов
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { 
  createOrder, 
  getOrderById, 
  getOrders, 
  updateOrderStatus,
  calculateOrder,
  addFileToOrder,
  getOrderStats,
} from '@/services/orders';
import { withAuth, withRole, rateLimit } from '@/middleware/auth';
import { 
  createOrderSchema, 
  updateOrderStatusSchema,
  calculateOrderSchema,
} from '@/validators/order.validator';
import { 
  sendOrderToProduction, 
  notifyStatusChange 
} from '@/lib/queue';
import { 
  updateTrafficSourceStats,
  sendFacebookPixelEvent,
  sendVKPixelEvent,
} from '@/services/smm';

// Rate limiting
const limiter = rateLimit({ windowMs: 60 * 1000, maxRequests: 100 });

// ============================================================================
// GET /api/orders - Получить список заказов
// ============================================================================

export const GET = withAuth(async (request: NextRequest, context) => {
  // Проверка rate limit
  const rateLimitResponse = await limiter(request);
  if (rateLimitResponse) return rateLimitResponse;
  
  const { searchParams } = new URL(request.url);
  
  // Параметры пагинации
  const page = parseInt(searchParams.get('page') || '1');
  const pageSize = parseInt(searchParams.get('pageSize') || '20');
  
  // Фильтры
  const status = searchParams.get('status') as string | null;
  
  // Для клиентов показываем только их заказы
  const clientId = context.role === 'CLIENT' ? context.userId : searchParams.get('clientId');
  
  // Если запрашивают статистику
  if (searchParams.get('stats') === 'true') {
    const stats = await getOrderStats(clientId);
    return NextResponse.json({ success: true, data: stats });
  }
  
  // Получаем список заказов
  const result = await getOrders({
    clientId,
    status: status as any,
    page,
    pageSize,
  });
  
  return NextResponse.json({
    success: true,
    ...result,
  });
});

// ============================================================================
// POST /api/orders - Создать новый заказ
// ============================================================================

export const POST = withAuth(async (request: NextRequest, context) => {
  // Проверка rate limit
  const rateLimitResponse = await limiter(request);
  if (rateLimitResponse) return rateLimitResponse;
  
  try {
    const body = await request.json();
    
    // Валидация
    const validatedData = createOrderSchema.parse(body);
    
    // Создаём заказ
    const order = await createOrder(validatedData, context.userId);
    
    // Обновляем статистику источника трафика
    if (validatedData.utmSource) {
      await updateTrafficSourceStats(validatedData.utmSource, 'lead');
    }
    
    // Отправляем событие Lead в Pixel
    await Promise.all([
      sendFacebookPixelEvent({
        eventName: 'Lead',
        userData: {
          externalId: context.userId,
        },
        customData: {
          contentName: validatedData.title,
          contentType: validatedData.category,
        },
      }),
      sendVKPixelEvent({
        eventName: 'Lead',
        userData: { externalId: context.userId },
      }),
    ]);
    
    return NextResponse.json({
      success: true,
      data: order,
      message: 'Заказ успешно создан',
    }, { status: 201 });
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Ошибка валидации',
        details: error.errors,
      }, { status: 400 });
    }
    
    console.error('Create order error:', error);
    return NextResponse.json({
      success: false,
      error: 'Не удалось создать заказ',
    }, { status: 500 });
  }
});

// ============================================================================
// PATCH /api/orders - Обновить статус заказа
// ============================================================================

export const PATCH = withRole(['MANAGER', 'ADMIN', 'PRODUCTION'])(async (request: NextRequest) => {
  const rateLimitResponse = await limiter(request);
  if (rateLimitResponse) return rateLimitResponse;
  
  try {
    const body = await request.json();
    const { orderId, ...data } = body;
    
    if (!orderId) {
      return NextResponse.json({
        success: false,
        error: 'ID заказа обязателен',
      }, { status: 400 });
    }
    
    // Проверяем тип операции
    if (data.estimatedPrice !== undefined) {
      // Расчёт заказа
      const validatedData = calculateOrderSchema.parse({
        orderId,
        estimatedPrice: data.estimatedPrice,
        estimatedDays: data.estimatedDays || 14,
        notes: data.notes,
      });
      
      const order = await calculateOrder(validatedData);
      
      // Уведомляем об изменении статуса
      await notifyStatusChange(order, 'CALCULATED', validatedData.notes);
      
      return NextResponse.json({
        success: true,
        data: order,
        message: 'Расчёт сохранён',
      });
    }
    
    // Обновление статуса
    const validatedData = updateOrderStatusSchema.parse(data);
    
    // Получаем текущий заказ
    const currentOrder = await db.order.findUnique({
      where: { id: orderId },
    });
    
    if (!currentOrder) {
      return NextResponse.json({
        success: false,
        error: 'Заказ не найден',
      }, { status: 404 });
    }
    
    // Обновляем статус
    const order = await updateOrderStatus(
      orderId,
      validatedData.status as any,
      validatedData.comment
    );
    
    // Уведомляем об изменении статуса
    await notifyStatusChange(order, validatedData.status, validatedData.comment);
    
    // Если статус CONFIRMED - отправляем в производство
    if (validatedData.status === 'CONFIRMED') {
      await sendOrderToProduction(order);
    }
    
    // Если статус COMPLETED - отправляем Purchase событие
    if (validatedData.status === 'COMPLETED' && order.finalPrice) {
      await Promise.all([
        sendFacebookPixelEvent({
          eventName: 'Purchase',
          customData: {
            value: order.finalPrice / 100, // Конвертируем из копеек
            currency: 'RUB',
          },
        }),
        sendVKPixelEvent({
          eventName: 'Purchase',
          customData: {
            value: order.finalPrice / 100,
            currency: 'RUB',
          },
        }),
      ]);
      
      // Обновляем статистику источника
      if (currentOrder.utmSource) {
        await updateTrafficSourceStats(currentOrder.utmSource, 'order');
        await updateTrafficSourceStats(
          currentOrder.utmSource,
          'revenue',
          order.finalPrice
        );
      }
    }
    
    return NextResponse.json({
      success: true,
      data: order,
      message: 'Статус обновлён',
    });
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Ошибка валидации',
        details: error.errors,
      }, { status: 400 });
    }
    
    console.error('Update order error:', error);
    return NextResponse.json({
      success: false,
      error: 'Не удалось обновить заказ',
    }, { status: 500 });
  }
});
