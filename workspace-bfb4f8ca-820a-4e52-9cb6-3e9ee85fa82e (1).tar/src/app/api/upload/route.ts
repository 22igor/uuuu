// ============================================================================
// API: /api/upload - Загрузка файлов
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { withAuth, rateLimit } from '@/middleware/auth';
import { 
  ALLOWED_FILE_TYPES, 
  MAX_FILE_SIZE, 
  fileUploadSchema 
} from '@/validators/order.validator';
import { addFileToOrder } from '@/services/orders';
import { db } from '@/lib/db';

const limiter = rateLimit({ windowMs: 60 * 1000, maxRequests: 20 });

// ============================================================================
// POST /api/upload - Загрузка файла
// ============================================================================

export const POST = withAuth(async (request: NextRequest) => {
  const rateLimitResponse = await limiter(request);
  if (rateLimitResponse) return rateLimitResponse;
  
  try {
    const formData = await request.formData();
    
    const file = formData.get('file') as File | null;
    const orderId = formData.get('orderId') as string | null;
    
    if (!file) {
      return NextResponse.json({
        success: false,
        error: 'Файл не предоставлен',
      }, { status: 400 });
    }
    
    // Валидация файла
    const fileValidation = fileUploadSchema.safeParse({
      fileName: file.name,
      fileSize: file.size,
      mimeType: file.type,
    });
    
    if (!fileValidation.success) {
      return NextResponse.json({
        success: false,
        error: 'Файл не прошёл валидацию',
        details: fileValidation.error.errors,
      }, { status: 400 });
    }
    
    // Генерируем уникальное имя файла
    const ext = file.name.split('.').pop() || 'bin';
    const uniqueName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const filePath = `uploads/${uniqueName}`;
    
    // В реальной системе здесь загрузка в S3/MinIO
    // Для демо сохраняем в public/uploads
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    
    // Сохраняем файл (используем Bun для записи)
    await Bun.write(`public/${filePath}`, buffer);
    
    // Если указан orderId - привязываем файл к заказу
    if (orderId) {
      const order = await db.order.findUnique({
        where: { id: orderId },
      });
      
      if (!order) {
        return NextResponse.json({
          success: false,
          error: 'Заказ не найден',
        }, { status: 404 });
      }
      
      await addFileToOrder(orderId, {
        fileName: file.name,
        filePath: `/${filePath}`,
        fileSize: file.size,
        mimeType: file.type,
      });
    }
    
    return NextResponse.json({
      success: true,
      data: {
        fileName: file.name,
        filePath: `/${filePath}`,
        fileSize: file.size,
        mimeType: file.type,
      },
      message: 'Файл успешно загружен',
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json({
      success: false,
      error: 'Не удалось загрузить файл',
    }, { status: 500 });
  }
});
