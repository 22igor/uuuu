// ============================================================================
// ORDERS SERVICE - Бизнес-логика заказов
// ============================================================================

import { db } from '@/lib/db';
import type { 
  Order, 
  OrderStatus, 
  OrderWithFiles,
  CreateOrderInput,
  OrderCalculation 
} from '@/types';

// ============================================================================
// Order Number Generation
// ============================================================================

function generateOrderNumber(): string {
  const year = new Date().getFullYear();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `МЕ-${year}-${random}`;
}

// ============================================================================
// CRUD Operations
// ============================================================================

export async function createOrder(
  data: CreateOrderInput,
  clientId: string
): Promise<Order> {
  const orderNumber = generateOrderNumber();
  
  // Определяем источник трафика по UTM
  let trafficSourceId: string | undefined;
  if (data.utmSource) {
    const source = await db.trafficSource.findFirst({
      where: { code: data.utmSource },
    });
    if (source) {
      trafficSourceId = source.id;
      // Обновляем статистику источника
      await db.trafficSource.update({
        where: { id: source.id },
        data: { totalLeads: { increment: 1 } },
      });
    }
  }
  
  const order = await db.order.create({
    data: {
      orderNumber,
      clientId,
      contactName: data.contactName,
      contactPhone: data.contactPhone,
      contactEmail: data.contactEmail,
      title: data.title,
      description: data.description,
      category: data.category,
      quantity: data.quantity,
      unit: data.unit,
      materialType: data.materialType,
      materialGrade: data.materialGrade,
      deliveryAddress: data.deliveryAddress,
      deliveryType: data.deliveryType,
      deadline: data.deadline ? new Date(data.deadline) : null,
      utmSource: data.utmSource,
      utmMedium: data.utmMedium,
      utmCampaign: data.utmCampaign,
      utmContent: data.utmContent,
      utmTerm: data.utmTerm,
      trafficSourceId,
      status: 'NEW',
    },
    include: {
      files: true,
    },
  });
  
  // Логируем начальный статус
  await logStatusChange(order.id, null, 'NEW', 'Заказ создан');
  
  return order;
}

export async function getOrderById(id: string): Promise<OrderWithFiles | null> {
  return db.order.findUnique({
    where: { id },
    include: {
      files: {
        select: {
          id: true,
          fileName: true,
          filePath: true,
        },
      },
    },
  });
}

export async function getOrders(options: {
  clientId?: string;
  status?: OrderStatus;
  page?: number;
  pageSize?: number;
}) {
  const { clientId, status, page = 1, pageSize = 20 } = options;
  
  const where = {
    ...(clientId && { clientId }),
    ...(status && { status }),
  };
  
  const [orders, total] = await Promise.all([
    db.order.findMany({
      where,
      include: {
        files: { select: { id: true, fileName: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    db.order.count({ where }),
  ]);
  
  return {
    data: orders,
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

// ============================================================================
// Status Management
// ============================================================================

export async function updateOrderStatus(
  orderId: string,
  newStatus: OrderStatus,
  comment?: string,
  changedBy?: string
): Promise<Order> {
  const order = await db.order.findUnique({
    where: { id: orderId },
    select: { status: true },
  });
  
  if (!order) {
    throw new Error('Заказ не найден');
  }
  
  const updatedOrder = await db.order.update({
    where: { id: orderId },
    data: {
      status: newStatus,
      ...(newStatus === 'CONFIRMED' && { confirmedAt: new Date() }),
      ...(newStatus === 'COMPLETED' && { completedAt: new Date() }),
    },
  });
  
  await logStatusChange(orderId, order.status, newStatus, comment, changedBy);
  
  return updatedOrder;
}

async function logStatusChange(
  orderId: string,
  fromStatus: OrderStatus | null,
  toStatus: OrderStatus,
  comment?: string,
  changedBy?: string
): Promise<void> {
  await db.orderStatusHistory.create({
    data: {
      orderId,
      fromStatus,
      toStatus,
      comment,
      changedBy,
    },
  });
}

// ============================================================================
// Calculation
// ============================================================================

export async function calculateOrder(data: OrderCalculation): Promise<Order> {
  const order = await db.order.update({
    where: { id: data.orderId },
    data: {
      estimatedPrice: data.estimatedPrice,
      status: 'CALCULATED',
    },
  });
  
  await logStatusChange(
    data.orderId,
    'CALCULATING',
    'CALCULATED',
    `Ориентировочный срок: ${data.estimatedDays} дней. ${data.notes || ''}`
  );
  
  return order;
}

// ============================================================================
// File Management
// ============================================================================

export async function addFileToOrder(
  orderId: string,
  file: {
    fileName: string;
    filePath: string;
    fileSize: number;
    mimeType: string;
  }
): Promise<Order> {
  await db.orderFile.create({
    data: {
      orderId,
      ...file,
    },
  });
  
  return db.order.findUnique({
    where: { id: orderId },
    include: { files: true },
  }) as Promise<Order>;
}

// ============================================================================
// Statistics
// ============================================================================

export async function getOrderStats(clientId?: string) {
  const where = clientId ? { clientId } : {};
  
  const [
    total,
    byStatus,
    totalRevenue,
  ] = await Promise.all([
    db.order.count({ where }),
    db.order.groupBy({
      by: ['status'],
      where,
      _count: true,
    }),
    db.order.aggregate({
      where: {
        ...where,
        finalPrice: { not: null },
      },
      _sum: { finalPrice: true },
    }),
  ]);
  
  return {
    total,
    byStatus: byStatus.reduce((acc, item) => {
      acc[item.status] = item._count;
      return acc;
    }, {} as Record<string, number>),
    totalRevenue: totalRevenue._sum.finalPrice || 0,
  };
}
