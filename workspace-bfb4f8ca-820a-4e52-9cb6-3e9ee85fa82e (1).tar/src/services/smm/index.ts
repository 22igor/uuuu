// ============================================================================
// SMM SERVICE - Маркетинг, UTM-трекинг, SMM посты
// ============================================================================

import { db } from '@/lib/db';
import type { SMMPost, TrafficSource, UTMParams, PixelEvent, SMMPostTemplate } from '@/types';

// ============================================================================
// UTM Tracking
// ============================================================================

export async function trackUTM(params: UTMParams): Promise<TrafficSource | null> {
  if (!params.utmSource) return null;
  
  // Ищем или создаём источник трафика
  let source = await db.trafficSource.findUnique({
    where: { code: params.utmSource },
  });
  
  if (!source) {
    // Создаём новый источник
    source = await db.trafficSource.create({
      data: {
        name: params.utmSource,
        code: params.utmSource,
        type: detectSourceType(params.utmSource),
        defaultUtmMedium: params.utmMedium,
        defaultUtmCampaign: params.utmCampaign,
      },
    });
  }
  
  return source;
}

function detectSourceType(source: string): string {
  const socialSources = ['vk', 'telegram', 'instagram', 'facebook', 'youtube'];
  const paidSources = ['google', 'yandex', 'facebook_ads', 'vk_ads'];
  
  if (socialSources.some(s => source.toLowerCase().includes(s))) {
    return 'SOCIAL';
  }
  if (paidSources.some(s => source.toLowerCase().includes(s))) {
    return 'PAID_SEARCH';
  }
  if (source.toLowerCase().includes('email')) {
    return 'EMAIL';
  }
  if (source.toLowerCase().includes('referral')) {
    return 'REFERRAL';
  }
  return 'ORGANIC';
}

export async function updateTrafficSourceStats(
  sourceCode: string,
  event: 'lead' | 'order' | 'revenue',
  value?: number
): Promise<void> {
  const source = await db.trafficSource.findUnique({
    where: { code: sourceCode },
  });
  
  if (!source) return;
  
  const updateData: Record<string, unknown> = {};
  
  switch (event) {
    case 'lead':
      updateData.totalLeads = { increment: 1 };
      break;
    case 'order':
      updateData.totalOrders = { increment: 1 };
      break;
    case 'revenue':
      updateData.totalRevenue = { increment: value || 0 };
      break;
  }
  
  await db.trafficSource.update({
    where: { id: source.id },
    data: updateData,
  });
}

// ============================================================================
// Pixel Integration
// ============================================================================

/**
 * Отправка событий в Facebook Pixel
 * Документация: https://developers.facebook.com/docs/marketing-api/conversions-api
 */
export async function sendFacebookPixelEvent(event: PixelEvent): Promise<boolean> {
  const pixelId = process.env.FACEBOOK_PIXEL_ID;
  const accessToken = process.env.FACEBOOK_PIXEL_ACCESS_TOKEN;
  
  if (!pixelId || !accessToken) {
    console.warn('Facebook Pixel не настроен');
    return false;
  }
  
  try {
    const response = await fetch(
      `https://graph.facebook.com/v18.0/${pixelId}/events`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          data: [{
            event_name: event.eventName,
            event_time: Math.floor(Date.now() / 1000),
            event_id: event.eventId,
            user_data: hashUserData(event.userData || {}),
            custom_data: event.customData,
            action_source: 'website',
          }],
          access_token: accessToken,
        }),
      }
    );
    
    return response.ok;
  } catch (error) {
    console.error('Facebook Pixel error:', error);
    return false;
  }
}

/**
 * Отправка событий в VK Pixel
 * Документация: https://vk.com/dev/vk_pixel_events
 */
export async function sendVKPixelEvent(event: PixelEvent): Promise<boolean> {
  const pixelId = process.env.VK_PIXEL_ID;
  
  if (!pixelId) {
    console.warn('VK Pixel не настроен');
    return false;
  }
  
  // VK Pixel отправляется с клиентской стороны
  // Этот метод используется для server-side tracking через VK Ads API
  console.log(`VK Pixel Event: ${event.eventName}`, event);
  return true;
}

/**
 * Хеширование данных пользователя для Pixel (SHA-256)
 */
function hashUserData(data: Record<string, string | undefined>): Record<string, string> {
  // В реальной реализации здесь должно быть SHA-256 хеширование
  // Для упрощения возвращаем заглушку
  const result: Record<string, string> = {};
  
  if (data.email) result.em = data.email.toLowerCase();
  if (data.phone) result.ph = data.phone.replace(/\D/g, '');
  if (data.externalId) result.external_id = data.externalId;
  
  return result;
}

// ============================================================================
// SMM Post Generation
// ============================================================================

const CASE_TEMPLATES = [
  {
    title: '🔨 Кейс выполнен: {title}',
    content: `✅ Успешно выполнен заказ #{orderNumber}

📦 Что делали: {title}
📊 Категория: {category}
🚚 Доставка: {deliveryType}

💡 Срок выполнения: {days} дней
💯 Качество — наше призвание!

📞 Хотите так же? Звоните: +7 (XXX) XXX-XX-XX
#металлоизделия #производство #метизы`,
  },
  {
    title: '⚡ Новый кейс: {title}',
    content: `🏭 Очередной заказ выполнен!

📋 Заказ: #{orderNumber}
🎯 Задача: {title}

Наша команда справилась в кратчайшие сроки!

✨ «МетизЭксперт» — надёжный партнёр в сфере металлообработки

#металлоконструкции #болты #крепёж`,
  },
];

const CATEGORY_LABELS: Record<string, string> = {
  FASTENERS: 'Крепёжные изделия',
  STRUCTURES: 'Металлоконструкции',
  SHEET_METAL: 'Листовой металл',
  PIPES: 'Трубы',
  CUSTOM: 'Нестандартное изделие',
};

const DELIVERY_LABELS: Record<string, string> = {
  PICKUP: 'Самовывоз',
  DELIVERY: 'Доставка',
  TRANSPORT: 'Транспортная компания',
};

/**
 * Генерация SMM поста по выполненному заказу
 */
export function generateCasePost(order: {
  orderNumber: string;
  title: string;
  category: string;
  deliveryType: string;
  createdAt: Date;
  completedAt: Date | null;
}): SMMPostTemplate {
  const template = CASE_TEMPLATES[Math.floor(Math.random() * CASE_TEMPLATES.length)];
  
  const days = order.completedAt
    ? Math.ceil((order.completedAt.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24))
    : 'N/A';
  
  const title = template.title
    .replace('{title}', order.title);
  
  const content = template.content
    .replace('{orderNumber}', order.orderNumber)
    .replace('{title}', order.title)
    .replace('{category}', CATEGORY_LABELS[order.category] || order.category)
    .replace('{deliveryType}', DELIVERY_LABELS[order.deliveryType] || order.deliveryType)
    .replace('{days}', String(days));
  
  return {
    title,
    content,
    tags: ['металлоизделия', 'производство', 'метизы'],
  };
}

/**
 * Создание SMM поста
 */
export async function createSMMPost(data: {
  orderId?: string;
  title: string;
  content: string;
  platform: string;
  imageUrl?: string;
}): Promise<SMMPost> {
  return db.sMMPost.create({
    data: {
      orderId: data.orderId,
      title: data.title,
      content: data.content,
      platform: data.platform as 'TELEGRAM' | 'VK' | 'FACEBOOK' | 'INSTAGRAM' | 'WEBSITE',
      imageUrl: data.imageUrl,
      status: 'DRAFT',
    },
  });
}

/**
 * Публикация в Telegram канал
 */
export async function publishToTelegram(post: SMMPost): Promise<boolean> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const channelId = process.env.TELEGRAM_CHANNEL_ID;
  
  if (!botToken || !channelId) {
    console.warn('Telegram не настроен');
    return false;
  }
  
  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: channelId,
        text: post.content,
        parse_mode: 'HTML',
      }),
    });
    
    const result = await response.json();
    
    if (result.ok) {
      await db.sMMPost.update({
        where: { id: post.id },
        data: {
          platformPostId: String(result.result.message_id),
          status: 'PUBLISHED',
          publishedAt: new Date(),
        },
      });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Telegram publish error:', error);
    return false;
  }
}

// ============================================================================
// Referral System
// ============================================================================

export async function processReferralBonus(
  referrerId: string,
  orderId: string,
  orderValue: number
): Promise<void> {
  // Бонус = 1% от суммы заказа в баллах
  const bonus = Math.ceil(orderValue * 0.01);
  
  await db.user.update({
    where: { id: referrerId },
    data: { bonusPoints: { increment: bonus } },
  });
  
  // Создаём уведомление
  await db.notification.create({
    data: {
      userId: referrerId,
      type: 'SYSTEM',
      title: 'Реферальный бонус',
      message: `Вам начислено ${bonus} бонусных баллов за заказ #${orderId}`,
    },
  });
}
