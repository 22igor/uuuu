// ============================================================================
// VALIDATORS - Zod схемы для валидации входных данных
// ============================================================================

import { z } from 'zod';

// ============================================================================
// Order Validators
// ============================================================================

export const createOrderSchema = z.object({
  // Контактные данные
  contactName: z.string()
    .min(2, 'Имя должно содержать минимум 2 символа')
    .max(100, 'Имя слишком длинное')
    .transform(s => s.trim()),
    
  contactPhone: z.string()
    .regex(/^\+?[0-9\s\-()]{10,20}$/, 'Некорректный формат телефона')
    .transform(s => s.replace(/\s|-|\(|\)/g, '')),
    
  contactEmail: z.string()
    .email('Некорректный email')
    .optional()
    .or(z.literal('')),
    
  // Детали заказа
  title: z.string()
    .min(5, 'Название должно содержать минимум 5 символов')
    .max(500, 'Название слишком длинное')
    .transform(s => s.trim()),
    
  description: z.string()
    .max(5000, 'Описание слишком длинное')
    .optional()
    .or(z.literal('')),
    
  category: z.enum(['FASTENERS', 'STRUCTURES', 'SHEET_METAL', 'PIPES', 'CUSTOM'], {
    errorMap: () => ({ message: 'Выберите категорию продукции' }),
  }),
  
  quantity: z.number()
    .int('Количество должно быть целым числом')
    .positive('Количество должно быть больше 0')
    .max(1000000, 'Слишком большое количество'),
    
  unit: z.string()
    .min(1, 'Укажите единицу измерения')
    .max(20, 'Единица измерения слишком длинная'),
    
  // Материал
  materialType: z.string().max(100).optional(),
  materialGrade: z.string().max(100).optional(),
  
  // Доставка
  deliveryAddress: z.string().max(500).optional(),
  deliveryType: z.enum(['PICKUP', 'DELIVERY', 'TRANSPORT']).default('PICKUP'),
  
  // Сроки
  deadline: z.string()
    .datetime({ message: 'Некорректный формат даты' })
    .optional()
    .or(z.literal(''))
    .refine(
      (val) => !val || new Date(val) > new Date(),
      'Срок должен быть в будущем'
    ),
    
  // UTM-метки
  utmSource: z.string().max(100).optional(),
  utmMedium: z.string().max(100).optional(),
  utmCampaign: z.string().max(100).optional(),
  utmContent: z.string().max(100).optional(),
  utmTerm: z.string().max(100).optional(),
  
  // Реферал
  referralCode: z.string().max(50).optional(),
});

export const updateOrderStatusSchema = z.object({
  status: z.enum([
    'NEW', 'CALCULATING', 'CALCULATED', 'CONFIRMED', 
    'IN_PRODUCTION', 'PRODUCTION_DONE', 'READY', 
    'DELIVERED', 'COMPLETED', 'CANCELLED'
  ]),
  comment: z.string().max(1000).optional(),
  estimatedPrice: z.number().int().positive().optional(),
  finalPrice: z.number().int().positive().optional(),
});

export const calculateOrderSchema = z.object({
  orderId: z.string().cuid(),
  estimatedPrice: z.number().int().positive(),
  estimatedDays: z.number().int().positive().max(365),
  notes: z.string().max(1000).optional(),
});

// ============================================================================
// Auth Validators
// ============================================================================

export const registerSchema = z.object({
  email: z.string()
    .email('Некорректный email')
    .min(1, 'Email обязателен'),
    
  password: z.string()
    .min(8, 'Пароль должен содержать минимум 8 символов')
    .max(100, 'Пароль слишком длинный')
    .regex(/[A-Z]/, 'Пароль должен содержать заглавную букву')
    .regex(/[a-z]/, 'Пароль должен содержать строчную букву')
    .regex(/[0-9]/, 'Пароль должен содержать цифру'),
    
  name: z.string()
    .min(2, 'Имя должно содержать минимум 2 символа')
    .max(100, 'Имя слишком длинное')
    .optional(),
    
  phone: z.string()
    .regex(/^\+?[0-9\s\-()]{10,20}$/, 'Некорректный формат телефона')
    .optional(),
    
  referralCode: z.string().max(50).optional(),
});

export const loginSchema = z.object({
  email: z.string().email('Некорректный email'),
  password: z.string().min(1, 'Пароль обязателен'),
});

// ============================================================================
// File Validators
// ============================================================================

export const ALLOWED_FILE_TYPES = [
  // Документы
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  // Изображения
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp',
  // CAD файлы
  'application/acad',           // .dwg
  'application/x-autocad',
  'image/vnd.dwg',
  'image/x-dwg',
  // Архивы
  'application/zip',
  'application/x-rar-compressed',
  'application/x-7z-compressed',
];

export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 MB

export const fileUploadSchema = z.object({
  fileName: z.string().max(255),
  fileSize: z.number().max(MAX_FILE_SIZE, 'Файл слишком большой (макс. 50 MB)'),
  mimeType: z.string().refine(
    (type) => ALLOWED_FILE_TYPES.includes(type) || type.startsWith('image/'),
    'Недопустимый тип файла'
  ),
});

// ============================================================================
// SMM Validators
// ============================================================================

export const createSMMPostSchema = z.object({
  orderId: z.string().cuid().optional(),
  title: z.string().min(5).max(200),
  content: z.string().min(10).max(5000),
  platform: z.enum(['TELEGRAM', 'VK', 'FACEBOOK', 'INSTAGRAM', 'WEBSITE']),
  imageUrl: z.string().url().optional(),
});

export const utmParamsSchema = z.object({
  utmSource: z.string().max(100).optional(),
  utmMedium: z.string().max(100).optional(),
  utmCampaign: z.string().max(100).optional(),
  utmContent: z.string().max(100).optional(),
  utmTerm: z.string().max(100).optional(),
});

// Type exports
export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type UpdateOrderStatusInput = z.infer<typeof updateOrderStatusSchema>;
export type CalculateOrderInput = z.infer<typeof calculateOrderSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateSMMPostInput = z.infer<typeof createSMMPostSchema>;
export type UTMParamsInput = z.infer<typeof utmParamsSchema>;
