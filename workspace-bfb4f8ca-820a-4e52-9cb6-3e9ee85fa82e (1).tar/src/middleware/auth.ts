// ============================================================================
// MIDDLEWARE - Auth & Rate Limiting
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, extractTokenFromHeader } from '@/lib/auth';

// ============================================================================
// Auth Middleware
// ============================================================================

interface AuthContext {
  userId: string;
  email: string;
  role: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace NodeJS {
    interface ProcessEnv {
      JWT_SECRET: string;
    }
  }
}

/**
 * Проверяет JWT токен и добавляет user context в заголовки
 * Используется как обёртка для API routes
 */
export function withAuth(
  handler: (request: NextRequest, context: AuthContext) => Promise<NextResponse>
) {
  return async (request: NextRequest) => {
    const authHeader = request.headers.get('authorization');
    const token = extractTokenFromHeader(authHeader);
    
    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Требуется авторизация' },
        { status: 401 }
      );
    }
    
    const payload = verifyToken(token);
    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Недействительный токен' },
        { status: 401 }
      );
    }
    
    return handler(request, {
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
    });
  };
}

/**
 * Проверяет роль пользователя
 */
export function withRole(roles: string[]) {
  return function (
    handler: (request: NextRequest, context: AuthContext) => Promise<NextResponse>
  ) {
    return withAuth(async (request, context) => {
      if (!roles.includes(context.role)) {
        return NextResponse.json(
          { success: false, error: 'Недостаточно прав' },
          { status: 403 }
        );
      }
      return handler(request, context);
    });
  };
}

// ============================================================================
// Rate Limiting (In-Memory, для продакшена использовать Redis)
// ============================================================================

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

export interface RateLimitConfig {
  windowMs: number;     // Временное окно в миллисекундах
  maxRequests: number;  // Максимум запросов в окне
  message?: string;     // Сообщение при превышении
}

const defaultConfig: RateLimitConfig = {
  windowMs: 60 * 1000,   // 1 минута
  maxRequests: 100,
  message: 'Слишком много запросов, попробуйте позже',
};

export function rateLimit(config: Partial<RateLimitConfig> = {}) {
  const { windowMs, maxRequests, message } = { ...defaultConfig, ...config };
  
  return async (request: NextRequest): Promise<NextResponse | null> => {
    // Получаем IP адрес
    const ip = request.headers.get('x-forwarded-for') 
      || request.headers.get('x-real-ip') 
      || 'unknown';
    
    const key = `${ip}:${request.nextUrl.pathname}`;
    const now = Date.now();
    
    const entry = rateLimitStore.get(key);
    
    if (!entry || now > entry.resetTime) {
      // Новое окно
      rateLimitStore.set(key, {
        count: 1,
        resetTime: now + windowMs,
      });
      return null;
    }
    
    if (entry.count >= maxRequests) {
      // Превышен лимит
      const retryAfter = Math.ceil((entry.resetTime - now) / 1000);
      return NextResponse.json(
        { success: false, error: message },
        {
          status: 429,
          headers: {
            'Retry-After': String(retryAfter),
            'X-RateLimit-Limit': String(maxRequests),
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': String(entry.resetTime),
          },
        }
      );
    }
    
    // Увеличиваем счётчик
    entry.count++;
    
    return null;
  };
}

// Очистка устаревших записей (каждые 5 минут)
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now > entry.resetTime) {
      rateLimitStore.delete(key);
    }
  }
}, 5 * 60 * 1000);

// ============================================================================
// Input Sanitization
// ============================================================================

/**
 * Очистка входных данных от XSS
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

export function sanitizeObject<T extends Record<string, unknown>>(obj: T): T {
  const result: Record<string, unknown> = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      result[key] = sanitizeInput(value);
    } else if (typeof value === 'object' && value !== null) {
      result[key] = sanitizeObject(value as Record<string, unknown>);
    } else {
      result[key] = value;
    }
  }
  
  return result as T;
}
