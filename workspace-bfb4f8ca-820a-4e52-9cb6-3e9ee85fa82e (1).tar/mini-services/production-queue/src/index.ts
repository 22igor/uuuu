// ============================================================================
// PRODUCTION QUEUE SERVICE
// ============================================================================
// Мини-сервис для обработки очереди задач производства
// Интеграция с Telegram, ERP системами
// 
// МИКРОСЕРВИС: При масштабировании выносится в отдельный сервис
// ============================================================================

import { Queue, Worker, Job } from 'bullmq';
import Redis from 'ioredis';

// ============================================================================
// Configuration
// ============================================================================

const REDIS_HOST = process.env.REDIS_HOST || 'localhost';
const REDIS_PORT = parseInt(process.env.REDIS_PORT || '6379');
const PORT = 3002;

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_PRODUCTION_CHAT_ID = process.env.TELEGRAM_PRODUCTION_CHAT_ID;

// ============================================================================
// Redis Connection
// ============================================================================

const connection = new Redis({
  host: REDIS_HOST,
  port: REDIS_PORT,
  maxRetriesPerRequest: null,
});

connection.on('error', (err) => {
  console.error('Redis connection error:', err);
});

connection.on('connect', () => {
  console.log('✅ Connected to Redis');
});

// ============================================================================
// Queue Setup
// ============================================================================

export const productionQueue = new Queue('production', {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 1000,
    },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

// ============================================================================
// Job Types
// ============================================================================

interface ProductionJobData {
  orderId: string;
  orderNumber: string;
  action: 'SEND_TO_PRODUCTION' | 'UPDATE_STATUS' | 'SEND_NOTIFICATION';
  payload?: {
    title?: string;
    description?: string;
    quantity?: number;
    material?: string;
    deadline?: string;
    status?: string;
    comment?: string;
    files?: Array<{ fileName: string; filePath: string }>;
    [key: string]: unknown;
  };
}

// ============================================================================
// Telegram Integration
// ============================================================================

async function sendTelegramMessage(
  chatId: string,
  text: string,
  parseMode: 'HTML' | 'Markdown' = 'HTML'
): Promise<boolean> {
  if (!TELEGRAM_BOT_TOKEN) {
    console.warn('⚠️ Telegram bot token not configured');
    return false;
  }

  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: parseMode,
        disable_web_page_preview: true,
      }),
    });

    const result = await response.json() as { ok: boolean; description?: string };
    
    if (!result.ok) {
      console.error('Telegram API error:', result.description);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Failed to send Telegram message:', error);
    return false;
  }
}

/**
 * Формирует красивое ТЗ для производства
 */
function formatProductionTask(data: ProductionJobData): string {
  const { orderNumber, payload } = data;
  const p = payload || {};

  return `
🏭 <b>НОВЫЙ ЗАКАЗ В ПРОИЗВОДСТВО</b>

📋 <b>Заказ:</b> #${orderNumber}
━━━━━━━━━━━━━━━━━━

📝 <b>Наименование:</b>
${p.title || 'Не указано'}

📏 <b>Количество:</b> ${p.quantity || '-'} ${p.unit || 'шт'}

🔩 <b>Материал:</b> ${p.material || 'Не указан'}

📅 <b>Срок:</b> ${p.deadline || 'По согласованию'}

📄 <b>Описание:</b>
${p.description || 'Без описания'}

${p.files && p.files.length > 0 ? `
📎 <b>Файлы:</b>
${p.files.map((f, i) => `${i + 1}. ${f.fileName}`).join('\n')}
` : ''}

━━━━━━━━━━━━━━━━━━
⚡ <i>Принято в работу: ${new Date().toLocaleString('ru-RU')}</i>
`.trim();
}

/**
 * Формирует уведомление об изменении статуса
 */
function formatStatusUpdate(data: ProductionJobData): string {
  const { orderNumber, payload } = data;
  const p = payload || {};

  return `
📊 <b>ОБНОВЛЕНИЕ СТАТУСА</b>

📋 Заказ: #${orderNumber}
🔄 Новый статус: <b>${p.status || '-'}</b>

💬 ${p.comment || 'Без комментария'}

━━━━━━━━━━━━━━━━━━
🕐 ${new Date().toLocaleString('ru-RU')}
`.trim();
}

// ============================================================================
// Job Handlers
// ============================================================================

async function handleSendToProduction(job: Job<ProductionJobData>): Promise<void> {
  console.log(`📤 Processing job ${job.id}: SEND_TO_PRODUCTION`);
  
  const data = job.data;
  
  // 1. Отправляем в Telegram канал производства
  if (TELEGRAM_PRODUCTION_CHAT_ID) {
    const message = formatProductionTask(data);
    const sent = await sendTelegramMessage(TELEGRAM_PRODUCTION_CHAT_ID, message);
    
    if (sent) {
      console.log(`✅ Telegram notification sent for order ${data.orderNumber}`);
    }
  }
  
  // 2. Интеграция с ERP (заглушка)
  // В реальной системе здесь будет API вызов к ERP
  console.log(`📊 ERP integration placeholder for order ${data.orderNumber}`);
  
  // TODO: Реализовать интеграцию с ERP
  // await erpIntegration.createProductionOrder(data);
}

async function handleStatusUpdate(job: Job<ProductionJobData>): Promise<void> {
  console.log(`📤 Processing job ${job.id}: UPDATE_STATUS`);
  
  const data = job.data;
  
  if (TELEGRAM_PRODUCTION_CHAT_ID) {
    const message = formatStatusUpdate(data);
    await sendTelegramMessage(TELEGRAM_PRODUCTION_CHAT_ID, message);
  }
}

async function handleNotification(job: Job<ProductionJobData>): Promise<void> {
  console.log(`📤 Processing job ${job.id}: SEND_NOTIFICATION`);
  
  const data = job.data;
  
  // Отправляем кастомное уведомление
  if (data.payload?.chatId && data.payload?.message) {
    await sendTelegramMessage(
      String(data.payload.chatId),
      String(data.payload.message)
    );
  }
}

// ============================================================================
// Worker
// ============================================================================

const worker = new Worker<ProductionJobData>(
  'production',
  async (job) => {
    const startTime = Date.now();
    
    try {
      console.log(`\n🚀 Starting job ${job.id} (${job.name})`);
      
      switch (job.data.action) {
        case 'SEND_TO_PRODUCTION':
          await handleSendToProduction(job);
          break;
        case 'UPDATE_STATUS':
          await handleStatusUpdate(job);
          break;
        case 'SEND_NOTIFICATION':
          await handleNotification(job);
          break;
        default:
          console.warn(`Unknown action: ${job.data.action}`);
      }
      
      const duration = Date.now() - startTime;
      console.log(`✅ Job ${job.id} completed in ${duration}ms`);
      
      return { success: true, duration };
    } catch (error) {
      console.error(`❌ Job ${job.id} failed:`, error);
      throw error;
    }
  },
  {
    connection,
    concurrency: 5,
  }
);

worker.on('completed', (job) => {
  console.log(`✅ Job ${job.id} completed successfully`);
});

worker.on('failed', (job, err) => {
  console.error(`❌ Job ${job?.id} failed:`, err.message);
});

worker.on('error', (err) => {
  console.error('Worker error:', err);
});

// ============================================================================
// HTTP Server (для health checks и добавления задач через API)
// ============================================================================

const server = Bun.serve({
  port: PORT,
  async fetch(request) {
    const url = new URL(request.url);
    
    // Health check
    if (url.pathname === '/health') {
      return Response.json({
        status: 'ok',
        queue: 'production',
        timestamp: new Date().toISOString(),
      });
    }
    
    // Добавить задачу в очередь
    if (url.pathname === '/api/jobs' && request.method === 'POST') {
      try {
        const data = await request.json() as ProductionJobData;
        
        const job = await productionQueue.add(data.action, data, {
          jobId: `order-${data.orderId}-${Date.now()}`,
        });
        
        return Response.json({
          success: true,
          jobId: job.id,
        });
      } catch (error) {
        return Response.json(
          { success: false, error: String(error) },
          { status: 400 }
        );
      }
    }
    
    // Статус очереди
    if (url.pathname === '/api/queue/status') {
      const [waiting, active, completed, failed] = await Promise.all([
        productionQueue.getWaitingCount(),
        productionQueue.getActiveCount(),
        productionQueue.getCompletedCount(),
        productionQueue.getFailedCount(),
      ]);
      
      return Response.json({
        waiting,
        active,
        completed,
        failed,
      });
    }
    
    return Response.json({ error: 'Not found' }, { status: 404 });
  },
});

console.log(`
╔════════════════════════════════════════════╗
║   🏭 Production Queue Service Started      ║
╠════════════════════════════════════════════╣
║   Port: ${PORT}                                 ║
║   Queue: production                         ║
║   Redis: ${REDIS_HOST}:${REDIS_PORT}                    ║
╚════════════════════════════════════════════╝
`);

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down...');
  await worker.close();
  await productionQueue.close();
  await connection.quit();
  server.stop();
  process.exit(0);
});
